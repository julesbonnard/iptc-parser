const multipart = require('parse-multipart')

exports.handler = (event, context, callback) => {
  if(!event['body-json']) return callback(null, {
    "isBase64Encoded": false,
    "statusCode": 200,
    "body": "WITHOUT BODY"
  })

  const bodyBuffer = new Buffer(event['body-json'].toString(), 'base64')
  const boundary = multipart.getBoundary(event.params.header['content-type'])
  const parts = mutlipart.Parse(bodyBuffer, boundary)

  callback(null, {
    "isBase64Encoded": false,
    "statusCode": 200,
    "body": "SUCCESS",
    "files": parts
  })
}